# app.py
from flask import Flask, request, jsonify, render_template
from telethon.sync import TelegramClient
import asyncio

api_id = 28880964
api_hash = 'a4e2146bceb7aa5c60f77756355d5b83'
bot_username = 'Kyra_AIbot'

app = Flask(__name__)
client = TelegramClient('meowsession', api_id, api_hash)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/send-message', methods=['POST'])
def send_message():
    data = request.get_json()
    print("📥 Received message from user:", data)

    user_message = data['message']
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    reply = loop.run_until_complete(handle_bot_conversation(user_message))
    print("🤖 Bot replied:", reply)

    return jsonify({'reply': reply})

async def handle_bot_conversation(user_message):
    await client.start()
    async with client.conversation(bot_username) as conv:
        await conv.send_message(user_message)
        response = await conv.get_response()
        return response.text

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=7700)